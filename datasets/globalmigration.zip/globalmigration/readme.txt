<-----------------------README file for US Migration dataset-------------------->


<-----------------------Description-------------------->
This package contains data from the World Bank Global Bilateral Migration Database. We include both the raw data and the 
dissim.mat file that was used for the Global migration experiment in the following paper:

	Paper: Persistent Homology of Asymmetric Networks: An Approach based on Dowker Filtrations
	Authors: Samir Chowdhury, Facundo M\'emoli
	arxiv: http://arxiv.org/abs/1608.05432

This network is normalized to have entries between 0 and 1.

Author: Samir Chowdhury


<-----------------------Usage-------------------->

If you use the files in this dataset for any academic reason, or otherwise, please give credit to the author 
and/or the World Bank, as appropriate.

