function [represent]=computePers(sk0,sk1,sk2,sk3,diam,filename)
import edu.stanford.math.plex4.*;

% Compute persistence
% Author: Samir Chowdhury
% Last accessed: 10.03.2016
% This code takes the skeleta produced by the dowker.m or rips.m files, and
% produces barcodes. Requires a valid javaplex installation.

if (nargin<5)
    stream=api.Plex4.createExplicitSimplexStream();
else
    stream = api.Plex4.createExplicitSimplexStream(diam); %use this for 
%     non-integer entry times; diam is upper bound on filtration times 
end

    if ~isempty(sk0)
        for v=1:size(sk0,1);
            stream.addVertex(sk0(v,1),sk0(v,2));
        end
    end

    if ~isempty(sk1)
        for e =1:size(sk1,1);
            stream.addElement(sk1(e,1:2), sk1(e,3)); 
        end
    end
    if ~isempty(sk2)
        for f=1:size(sk2,1);
            stream.addElement(sk2(f,1:3),sk2(f,4));
        end
    end

if ~isempty(sk3)
    for g=1:size(sk3,1);
        stream.addElement(sk3(g,1:4),sk3(g,5));
    end
end

stream.finalizeStream();
% compute 3 dimensions (homology dimensions 0,1,2) with Z2 coeff
persistence = api.Plex4.getModularSimplicialAlgorithm(3,2); %Coordinates 
% are in the format (n,m), where n = number of dimensions to compute, and
% m indicates Zm coefficients.
intervals = persistence.computeIntervals(stream);
represent=persistence.computeAnnotatedIntervals(stream);

if (nargin>5)
options.filename = filename;
options.file_format = 'fig';
% options.filename='testsimplenet2';
options.max_filtration_value = diam;
plot_barcodes(intervals, options);
end

end

