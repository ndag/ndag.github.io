function A = cycleNetwork(n,w)
% This function creates the adjacency matrix of a directed cycle network 
% with n nodes and uniform weights w. 

v=ones(n-1,1)*w;
A=diag(v,1);
A(n,1)=w;
A=sparse(A);
A=graphallshortestpaths(A);
end