<-----------------------README file for Persistent Homology of Networks code-------------------->

Author: Samir Chowdhury
Last accessed: 8.22.2016

<-----------------------Description-------------------->
The files included in this package can compute Dowker persistence barcodes of general networks,
as described in the following paper:

	Paper: Persistent Homology of Asymmetric Networks: An Approach based on Dowker Filtrations
	Authors: Samir Chowdhury, Facundo M\'emoli
	arxiv: http://arxiv.org/abs/1608.05432

<-----------------------Usage-------------------->

To use the matlab files provided here, you must have a valid installation of Javaplex. You can find javaplex on:

https://github.com/appliedtopology/javaplex

You will also need the VChooseK function available here:

https://www.mathworks.com/matlabcentral/fileexchange/26190-vchoosek

Or you can replace the lines of code containing VChooseK with Matlab's native nchoosek.

<---->

Example: Cycle Networks

Suppose you want to compute a persistence diagram for a cycle network, as described in the main paper. In Matlab, type in:

A=cycleNetwork(5,1); %this will create a 5-node cycle network, with weights in the "forward direction" equal to 1.

diam=max(max(A)); %diameter will be equal to 4.

[sk0,sk1,sk2,sk3]=dowker(A) % if you only care about 1-dim persistence, write [sk0,sk1,sk2] as the output instead, and replace
							% sk3 by [] in the next line

computePers(sk0,sk1,sk2,sk3,diam*1.5,'test') %this will compute the Dowker persistence barcode. 



<-----------------------Legal Terms-------------------->

THIS SOFTWARE IS PROVIDED "AS-IS". THERE IS NO WARRANTY OF ANY KIND.
THE AUTHOR WILL NOT BE LIABLE FOR
ANY DAMAGES OF ANY KIND, EVEN IF ADVISED OF SUCH POSSIBILITY.


    Copyright (C) <2016>  <Samir Chowdhury>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.