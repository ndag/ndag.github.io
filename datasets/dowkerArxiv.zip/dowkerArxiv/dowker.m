function [sk0,sk1,sk2,sk3]=dowker(A)
% Function to compute Dowker sink filtration for a matrix A
% Input: square matrix A. Output: 0-3 skeleta with entry times
% Author: Samir Chowdhury
% Date: 9.22.2016
% Aux functions: VChooseK package needs to be compiled, available here:
% https://www.mathworks.com/matlabcentral/fileexchange/26190-vchoosek
% Also might need a C compiler such as MinGW:
% http://www.mathworks.com/matlabcentral/fileexchange/52848-matlab-support-for-the-mingw-w64-c-c++-compiler-from-tdm-gcc

n=length(A);
diam=max(max(A));
% Build 0-skeleton
% Entry time of vertex i is just min(A(i,:))
eT=min(A,[],2);
sk0=[[1:n]',eT];

% Build 1-skeleton
q=VChooseK(1:n,2); 
% Initialize sk1 with max entry time
sk1=[q,diam*ones(size(q,1),1)];
for ii=1:size(q,1)
    aI=A(q(ii,1),:);
    aJ=A(q(ii,2),:);
    aIJ=max([aI;aJ]);
    eT=min(aIJ);
    sk1(ii,end)=eT;
end

if (nargout>2)
% Build 2-skeleton
q=VChooseK(1:n,3); 
% Initialize sk2 with max entry time
sk2=[q,diam*ones(size(q,1),1)];
for ii=1:size(q,1)
    aI=A(q(ii,1),:);
    aJ=A(q(ii,2),:);
    aK=A(q(ii,3),:);
    aIJK=max([aI;aJ;aK]);
    eT=min(aIJK);
    sk2(ii,end)=eT;
end
end

if (nargout>3)
   % Build 3-skeleton
q=VChooseK(1:n,4); 
% Initialize sk3 with max entry time
sk3=[q,diam*ones(size(q,1),1)];
for ii=1:size(q,1)
    aI=A(q(ii,1),:);
    aJ=A(q(ii,2),:);
    aK=A(q(ii,3),:);
    aL=A(q(ii,4),:);
    aIJKL=max([aI;aJ;aK;aL]);
    eT=min(aIJKL);
    sk3(ii,end)=eT;
end 
end
end
