<-----------------------README file for US Economy dataset-------------------->

-- Thanks to Santiago Segarra for providing a curated version of the raw dataset, which can be found on www.bea.gov.
 

<-----------------------Description-------------------->
This package contains a dissim.mat file and a labels.mat file. 

The dissim.mat file in this package was used for the US economy experiment in the following paper:

	Paper: Persistent Homology of Asymmetric Networks: An Approach based on Dowker Filtrations
	Authors: Samir Chowdhury, Facundo M\'emoli
	arxiv: http://arxiv.org/abs/1608.05432

This network is normalized to have entries between 0 and 1.

Author (of .mat files): Samir Chowdhury


<-----------------------Usage-------------------->

If you use the .mat files in this dataset for any academic reason, or otherwise, please give credit to the author.

