%% demoLocSpecEcon
% Script to run local spec matching on small US economy database

mainfolder=pwd;
workfolder=[pwd,'/econsmall/'];
res_folder = [workfolder,'/res_loc_spec/'];

cd(mainfolder)
mkdir(res_folder)
cd(workfolder)
dire = dir('dissim*.mat');
%%%%%%%%

Nshapes = length(dire);

p=nchoosek(1:Nshapes,2);

addpath(mainfolder)

for i=1:length(p)
%for i=1:length(p)
   x=p(i,1);
   y=p(i,2);

    ni = sprintf('res_%d_%d.mat',x,y);
    fi = [res_folder '/' ni];%change slash depending on local/terminal    

  if ~exist(fi)

   a=load(dire(x).name);
   b=load(dire(y).name);

   sX = a.var;
   sY = b.var;

   [~,c]=matchLocSpec(sX,sY);

%    c = threshods(t);
   fprintf('result %d vs %d = %f\n',x,y,c)

    res = struct('c',c,'x',x,'y',y,'i',i,'name_x',dire(x).name,'name_y',dire(y).name);
 
    [c]

    writemyfile(fi,res)

end

end
                                                                                
disp('done')    

%% Reconstitute
cd(res_folder)

n = 19; %//Change this depending on size of database

dmat=zeros(n);

res = dir('res_*.mat');
nres = length(res);

for k=1:nres
    rk = load(res(k).name);
rk = rk.var;
    ik = rk.x;
    jk = rk.y;
    d  = rk.c;
    dmat(ik,jk)=d;
    %if rem(k,)
end

dmat = max(dmat,dmat');

save('output_dmat.mat','dmat')

%% Make labels
cd(workfolder);
dire=dir('dissim*');
labels=cell(size(dire));

for ii=1:length(labels)
    nm=dire(ii).name;
    labels{ii}=[nm(7:10)];
end
cd(mainfolder);


%% Plot dendrogram

figure
M=squareform(dmat);
Y=linkage(M);
dendrogram(Y,0,'Orientation','right','Labels',labels);
