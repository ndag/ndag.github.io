%% demoDowkerEcon
% Script to compute Dowker persistence barcodes from small economy
% database

clear all
mainfolder=pwd;
dissimfolder=[mainfolder,'/econsmall/'];
skelfolder=[mainfolder,'/econsmall/allSkeleta/'];
barfolder=[mainfolder,'/econsmall/allBarcodes/'];
resfolder=[mainfolder,'/econsmall/res_bottleneck/'];
rehash();
mkdir(skelfolder);
mkdir(barfolder);
mkdir(resfolder);
import edu.stanford.math.plex4.*;

%% Compute skeleta
incr=100;
cd(dissimfolder);
dire = dir('dissim*');

for i=1:length(dire)
    year=str2double(dire(i).name(7:10));
    fn=[skelfolder,'pers',sprintf('%04d',year),'.mat'];

  if ~exist(fn,'file')

   a=load(dire(i).name);

   sX = a.var;
   diam=max(max(sX));
   
   [sk0,sk1,sk2]=dowker(sX);

   fprintf('done for %d \n',i)

   res = struct('diam',diam,'sk0',sk0,'sk1',sk1,'sk2',sk2,'year',year,'name',dire(i).name);
 
   writemyfile(fn,res)
  end

end

%% PlotBarcodes; 
%This step is time consuming. It computes barcodes from the precomputed
%skeleta.
cd(skelfolder)

dire=dir('pers*.mat');

for ii=1:length(dire)
    res_name=dire(ii).name(1:end-4);%remove '.mat'
    if ~exist([skelfolder,res_name,'.fig'],'file')
        A=load(dire(ii).name);
        [sk0,sk1,sk2,diam]=pulltruncatedsk(A);
        sk3=[];
        computePers(sk0,sk1,sk2,sk3,diam,res_name,barfolder);
%         saveas(gcf,res_name);
        close all
    end
end

cd(mainfolder);

%% DPers; 
% This step computes bottleneck distances between pairs of barcodes
cd(barfolder);
dire=dir('bars*.mat');
numFiles=length(dire);
p=nchoosek(1:numFiles,2);

for i=1:length(p) %edit this to 1:length(p)

    x=p(i,1);
    y=p(i,2);
    
    ni = sprintf('res_%d_%d.mat',x,y);
    fi = [resfolder ni];%change slash depending on local/terminal
    
    if ~exist(fi,'file')

    intA=load(dire(x).name);
    intA=intA.bars;
    intB=load(dire(y).name);
    intB=intB.bars;
    
    
    [f,~,~] = distBarcode(intA{1},intB{1});
    [~,~,cm] = bottleneck(f);
    bottleneck_distance_dim0 = cm;
    [f,~,~] = distBarcode(intA{2},intB{2});
    [~,~,cm] = bottleneck(f);
    bottleneck_distance_dim1=cm;
       
intervalsA=[];
interalsB=[];
intervalsA_dim0=[];
intervalsA_dim1=[];
intervalsB_dim0=[];
intervalsB_dim1=[];
    fprintf('result %d vs %d = %f\n',x,y,bottleneck_distance_dim0)
    fprintf('result %d vs %d = %f\n',x,y,bottleneck_distance_dim1)

    res = struct('x',x,'y',y,'dim0_bdist',bottleneck_distance_dim0,'dim1_bdist',bottleneck_distance_dim1,'name_x',dire(x).name,'name_y',dire(y).name);
 
    writemyfile(fi,res)
    end
end

%% reconstBottleneck;
% This step places the pairwise bottleneck distances into matrix form
cd(resfolder);
n = 19; %//Change this depending on size of database
b0mat = zeros(n);
b1mat=zeros(n);

res = dir('res_*.mat');
nres = length(res);

for k=1:nres
    rk = load(res(k).name);
rk = rk.var;
    ik = rk.x;
    jk = rk.y;
    b0 = rk.dim0_bdist;
    b1 = rk.dim1_bdist;
    
    b0mat(ik,jk)=b0;
    b1mat(ik,jk)=b1;
    %if rem(k,)
end

b0mat = max(b0mat,b0mat');
b1mat = max(b1mat,b1mat');

save('output_dim0.mat','b0mat')
save('output_dim1.mat','b1mat')

%% Create labels
cd(barfolder);
dire=dir('bars*');
labels=cell(size(dire));

for ii=1:length(labels)
    nm=dire(ii).name;
    labels{ii}=[nm(end-7:end-4)];
end
cd(mainfolder);
%% Plot dendrogram with labels
figure
M=squareform(b1mat);
Y=linkage(M);
dendrogram(Y,0,'Orientation','right','Labels',labels);
